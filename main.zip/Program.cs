namespace GSL;

using System;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.IO.Compression;

class Program {
    static void Main(string[] args) {
        Interpreter interpreter = new Interpreter();

        if (args.Length > 0) {
            string cmd = args[0].ToLower();

            // gsp command - run GSL script
            if (cmd == "gsp") {
                if (args.Length < 2) {
                    Console.WriteLine("Usasge - gsp <filename>.gsl");
                    return;
                }
                string filename = args[1];
                if (!filename.EndsWith(".gsl")) filename += ".gsl";
                
                if (!File.Exists(filename)) {
                    Console.WriteLine($"File not found: {filename}");
                    return;
                }

                ExecuteWithReporting(filename, interpreter);
                return;
            }

            // lcsp command - link custom plugin
            if (cmd == "lcsp") {
                if (args.Length < 2) {
                    Console.WriteLine("Usage - lcsp <pluginname>");
                    return;
                }
                string pluginArg = args[1];
                string pluginPath = $"plugins/{pluginArg}";

                if (Directory.Exists(pluginPath)) {
                    string[] candidates = { "main.gsl", "init.gsl", "core.gsl" };
                    bool found = false;
                    foreach (var file in candidates) {
                        string tryPath = Path.Combine(pluginPath, file);
                        if (File.Exists(tryPath)) {
                            ExecuteWithReporting(tryPath, interpreter);
                            Console.WriteLine($"Plugin '{pluginArg}/{file}' loaded.");
                            found = true;
                            break;
                        }
                    }
                    if (!found) Console.WriteLine($"No main.gsl, init.gsl, or core.gsl found in {pluginPath}");
                    return;
                } 
                
                if (File.Exists(pluginPath + ".gsl")) pluginPath += ".gsl";
                
                if (!File.Exists(pluginPath)) {
                    Console.WriteLine($"Plugin not found: {pluginPath}");
                    return;
                }

                ExecuteWithReporting(pluginPath, interpreter);
                return;
            }

            // pcsp command - plugin custom source pull
            if (cmd == "pcsp") {
                HandlePcsp(args);
                return;
            }

            ShowHelp();
        } else {
            ShowHelp();
        }
    }

    /// <summary>
    /// Core execution logic with the colored Error Wrapper
    /// </summary>
    static void ExecuteWithReporting(string filePath, Interpreter interpreter) {
        string src = File.ReadAllText(filePath);
        try {
            var tokens = new Lexer(src).TokenizeAll();
            var ast = new Parser(tokens).Parse();
            interpreter.Run(ast);
        } catch (Exception ex) {
            ReportError(ex, src);
        }
    }

    /// <summary>
    /// Formats and prints errors with high-contrast colors and code snippets
    /// </summary>
    static void ReportError(Exception ex, string source) {
        // 1. Extract Line Number from exception message "[Line X]"
        int lineNum = 1;
        var match = Regex.Match(ex.Message, @"\[Line (\d+)\]");
        if (match.Success) lineNum = int.Parse(match.Groups[1].Value);

        // 2. Determine Error Phase and Color Theme
        string type = "RUNTIME ERROR";
        ConsoleColor theme = ConsoleColor.Red;

        if (ex.Message.Contains("Lex error")) {
            type = "LEXER ERROR";
            theme = ConsoleColor.Magenta;
        } else if (ex.Message.Contains("Parse error")) {
            type = "PARSER ERROR";
            theme = ConsoleColor.Cyan;
        }

        // 3. Print Header Badge
        Console.WriteLine();
        Console.BackgroundColor = theme;
        Console.ForegroundColor = ConsoleColor.Black;
        Console.Write($" {type} ");
        Console.ResetColor();
        Console.ForegroundColor = ConsoleColor.Gray;
        Console.WriteLine($" at line {lineNum}");

        // 4. Print Clean Message (stripping internal tags)
        string cleanMsg = Regex.Replace(ex.Message, @"\[Line \d+\] (Lex error: |Parse error: )?", "");
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine($" > {cleanMsg}");
        Console.ResetColor();

        // 5. Code Snippet Visualization
        string[] lines = source.Split('\n');
        if (lineNum > 0 && lineNum <= lines.Length) {
            Console.WriteLine();
            string lineContent = lines[lineNum - 1].TrimEnd().Replace("\r", "");
            
            // Gutter and Code line
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.Write($"{lineNum.ToString().PadLeft(4)} | ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(lineContent);
            
            // Caret pointer
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine($"     | {new string('^', Math.Max(1, lineContent.Length))}");
        }
        Console.WriteLine();
        Console.ResetColor();
    }

    static void HandlePcsp(string[] args) {
        if (args.Length < 2) {
            Console.WriteLine("Usage - pcsp <url> ");
            return;
        }
        
        string url = args[1];
        string? pluginName = null;

        if (args.Length >= 3) {
            pluginName = args[2];
        } else if (url.Contains(" ")) {
            var urlParts = url.Split(' ', 2);
            url = urlParts[0];
            pluginName = urlParts[1].Trim();
        }

        if (pluginName == null) {
            try {
                pluginName = Path.GetFileNameWithoutExtension(new Uri(url).AbsolutePath);
            } catch {
                pluginName = "plugin" + DateTime.Now.Ticks;
            }
        }

        // Handle Pastebin/Direct GSL Download
        if (url.Contains("pastebin.com/raw/") || url.EndsWith(".gsl")) {
            string path = $"plugins/{pluginName}.gsl";
            try {
                using var client = new WebClient();
                client.DownloadFile(url, path);
                Console.WriteLine($"Plugin downloaded to {path}");
            } catch (Exception ex) {
                Console.WriteLine($"Error downloading plugin: {ex.Message}");
            }
            return;
        }

        // Handle GitHub repo heads
        if (url.Contains("github.com") && !url.EndsWith(".zip")) {
            if (url.EndsWith("/")) url = url.Substring(0, url.Length - 1);
            url += "/archive/refs/heads/main.zip";
        }

        // Handle ZIP extraction
        if (url.EndsWith(".zip")) {
            string zipPath = $"plugins/{pluginName}.zip";
            string extractPath = $"plugins/{pluginName}";
            try {
                using (var client = new WebClient()) {
                    client.DownloadFile(url, zipPath);
                }
                if (Directory.Exists(extractPath)) Directory.Delete(extractPath, true);
                
                ZipFile.ExtractToDirectory(zipPath, extractPath);
                File.Delete(zipPath);
                
                Console.WriteLine($"Plugin extracted to {extractPath}");
                
                string readmePath = Path.Combine(extractPath, "README.md");
                if (File.Exists(readmePath)) {
                    Console.WriteLine("--- README.md ---");
                    Console.WriteLine(File.ReadAllText(readmePath));
                    Console.WriteLine("-----------------");
                }
            } catch (Exception ex) {
                Console.WriteLine($"Error processing ZIP plugin: {ex.Message}");
            }
            return;
        }

        Console.WriteLine("Unknown plugin source type. Supported: Pastebin, .gsl, GitHub, .zip");
    }

    static void ShowHelp() {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("GSL Language Environment");
        Console.ResetColor();
        Console.WriteLine("Usage:");
        Console.WriteLine("  gsp <filename>.gsl   - Run a GSL script");
        Console.WriteLine("  lcsp <pluginname>    - Load a local custom plugin");
        Console.WriteLine("  pcsp <url> [name]    - Pull a plugin from a remote source");
        Console.WriteLine();
    }
}