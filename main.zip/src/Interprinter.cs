using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

enum VType { Null, Int, Float, Bool, String, List, Map }

class Value {
    public VType       Type;
    public long        IVal;
    public double      FVal;
    public string?     SVal;
    public List<Value>?               List;
    public Dictionary<string, Value>? Map;

    public static Value Null()          => new Value { Type=VType.Null };
    public static Value Int(long v)     => new Value { Type=VType.Int,    IVal=v, FVal=v };
    public static Value Float(double v) => new Value { Type=VType.Float,  FVal=v, IVal=(long)v };
    public static Value Bool(bool v)    => new Value { Type=VType.Bool,   IVal=v?1:0 };
    public static Value Str(string? v)  => new Value { Type=VType.String, SVal=v ?? "" };
    public static Value NewList()       => new Value { Type=VType.List,   List=new List<Value>() };
    public static Value NewMap()        => new Value { Type=VType.Map,    Map=new Dictionary<string, Value>() };

    public bool Truthy() => Type switch {
        VType.Null   => false,
        VType.Bool   => IVal != 0,
        VType.Int    => IVal != 0,
        VType.Float  => FVal != 0.0,
        VType.String => SVal != null && SVal.Length > 0,
        VType.List   => List != null && List.Count > 0,
        VType.Map    => Map  != null && Map.Count  > 0,
        _ => false
    };

    public string KindOf() => Type switch {
        VType.Null   => "null",
        VType.Int    => "int",
        VType.Float  => "float",
        VType.Bool   => "bool",
        VType.String => "string",
        VType.List   => "list",
        VType.Map    => "map",
        _ => "unknown"
    };

    public Value Copy() {
        if (Type == VType.List && List != null) {
            var nv = NewList();
            foreach (var item in List) nv.List!.Add(item.Copy());
            return nv;
        }
        if (Type == VType.Map && Map != null) {
            var nv = NewMap();
            foreach (var kv in Map) nv.Map![kv.Key] = kv.Value.Copy();
            return nv;
        }
        return new Value { Type=Type, IVal=IVal, FVal=FVal, SVal=SVal };
    }

    public override string ToString() => Type switch {
        VType.Null   => "null",
        VType.Bool   => IVal != 0 ? "true" : "false",
        VType.Int    => IVal.ToString(),
        VType.Float  => FVal.ToString("G"),
        VType.String => SVal ?? "",
        VType.List   => List != null ? "[" + string.Join(", ", List) + "]" : "[]",
        VType.Map    => Map  != null ? "{" + string.Join(", ", Map.Select(kv => $"\"{kv.Key}\": {kv.Value}")) + "}" : "{}",
        _ => "null"
    };
}

class ReturnException : Exception { public Value Val; public ReturnException(Value v) { Val = v; } }
class StopException   : Exception { public StopException()  : base("stop")  {} }
class SkipException   : Exception { public SkipException()  : base("skip")  {} }

class Env {
    readonly Dictionary<string, Value> _vars = new();
    readonly Env? _parent;

    public Env(Env? parent = null) { _parent = parent; }

    public void Define(string name, Value val) => _vars[name] = val;

    public void Set(string name, Value val) {
        if (_vars.ContainsKey(name)) { _vars[name] = val; return; }
        if (_parent != null && _parent.Has(name)) { _parent.Set(name, val); return; }
        _vars[name] = val;
    }

    public Value Get(string name) {
        if (_vars.TryGetValue(name, out var v)) return v;
        if (_parent != null) return _parent.Get(name);
        throw new Exception($"Variable '{name}' not defined");
    }

    public bool Has(string name) {
        if (_vars.ContainsKey(name)) return true;
        return _parent != null && _parent.Has(name);
    }
}

class Interpreter {
    readonly Env                            _global = new();
    readonly Dictionary<string, CraftStmt> _funcs  = new();
    readonly Random                         _rng    = new();
    readonly HashSet<string>                _linkedPlugins    = new();
    readonly HashSet<string>                _loadedStdModules = new();
    readonly Dictionary<string, string>     _stdFunctionMap   = new();

    public void Run(BlockNode block) {
        RegisterBuiltins();
        foreach (var stmt in block.Stmts!)
            if (stmt is LinkStmt link && link.Module != null)
                LoadPlugin(link.Module);
        ExecBlock(block.Stmts!, _global);
    }

    // Built-ins
    readonly HashSet<string> _builtins = new();

    void RegisterBuiltins() {
        foreach (var name in new[] {
            "__tostr",
            "print", "println", "print_int", "print_float", "print_string", "print_bool", "print_list",
            "input", "input_line", "input_int", "input_float", "input_string",
            "read_file", "write_file", "append_file", "file_exists", "file_size", "delete_file",
            "list_files", "list_dirs", "get_cwd", "set_cwd",
            "exit", "sleep", "time", "timestamp",
            "format_int", "format_float", "format_string", "printf", "sprintf",
            "to_int", "to_float", "to_string",
            "is_int", "is_float", "is_string", "is_list", "is_bool",
            "repeat_str", "contains", "startswith", "endswith", "isempty",
            "str_reverse", "str_count", "str_join", "str_pad_left", "str_pad_right",
            "str_len", "str_concat", "str_repeat", "str_contains", "str_starts_with",
            "str_ends_with", "str_is_empty", "str_indexof", "str_replace",
            "substring", "split", "trim", "to_upper", "to_lower",
            "list_get", "list_first", "list_last", "list_contains", "list_indexof",
            "list_count", "list_sum", "list_max", "list_min", "list_reverse",
            "list_copy", "list_concat", "list_fill", "list_range", "list_swap",
            "list_sort", "list_unique",
            "pi", "e", "tau", "phi", "inf",
            "abs", "sign", "max", "min", "clamp", "saturate", "mod",
            "is_even", "is_odd", "is_pos", "is_neg", "is_zero", "wrap",
            "floor", "ceil", "round", "round_to", "trunc", "frac",
            "pow", "sqrt", "cbrt", "nroot", "hypot",
            "ln", "log2", "log10", "log_base", "exp",
            "sin", "cos", "tan", "atan", "atan2", "asin", "acos",
            "deg_to_rad", "rad_to_deg",
            "gcd", "lcm", "isprime", "factorial", "choose", "fib",
            "sum", "product", "average", "sumsq", "variance", "stddev",
            "dot", "lerp", "remap",
        }) _builtins.Add(name);
    }

    Value CallBuiltin(string name, List<Value> args) {
        Value A(int i) => i < args.Count ? args[i] : Value.Null();
        double D(int i) => A(i).Type == VType.Float ? A(i).FVal : A(i).IVal;
        long   L(int i) => A(i).Type == VType.Int   ? A(i).IVal : (long)A(i).FVal;
        string S(int i) => A(i).ToString();

        switch (name) {

        // Internal
        case "__tostr": return Value.Str(args.Count > 0 ? args[0].ToString() : "");

        // IO
        case "print":
            Console.Write(S(0));
            return Value.Null();
        case "println":
            Console.WriteLine(S(0));
            return Value.Null();
        case "print_int":
            Console.Write(L(0).ToString());
            return Value.Null();
        case "print_float":
            Console.Write(D(0).ToString("G"));
            return Value.Null();
        case "print_string":
            Console.Write(S(0));
            return Value.Null();
        case "print_bool":
            Console.Write(A(0).Truthy() ? "true" : "false");
            return Value.Null();
        case "print_list": {
            var lst = A(0);
            if (lst.Type != VType.List) throw new Exception("print_list requires a list");
            Console.Write("[");
            for (int i = 0; i < lst.List!.Count; i++) {
                if (i > 0) Console.Write(", ");
                Console.Write(lst.List[i]);
            }
            Console.Write("]");
            return Value.Null();
        }
        case "input":
        case "input_line": {
            string inp = Console.ReadLine() ?? "";
            return Value.Str(inp);
        }
        case "input_int": {
            Console.Write(S(0) + " ");
            string inp = Console.ReadLine() ?? "0";
            return long.TryParse(inp, out long iv) ? Value.Int(iv) : Value.Int(0);
        }
        case "input_float": {
            Console.Write(S(0) + " ");
            string inp = Console.ReadLine() ?? "0";
            return double.TryParse(inp, out double fv) ? Value.Float(fv) : Value.Float(0);
        }
        case "input_string": {
            Console.Write(S(0) + " ");
            return Value.Str(Console.ReadLine() ?? "");
        }
        case "read_file": {
            string path = S(0);
            if (!File.Exists(path)) throw new Exception($"File not found: {path}");
            return Value.Str(File.ReadAllText(path));
        }
        case "write_file":
            File.WriteAllText(S(0), S(1));
            return Value.Null();
        case "append_file":
            File.AppendAllText(S(0), S(1));
            return Value.Null();
        case "file_exists":
            return Value.Bool(File.Exists(S(0)));
        case "file_size":
            return File.Exists(S(0)) ? Value.Int(new FileInfo(S(0)).Length) : Value.Int(-1);
        case "delete_file":
            if (File.Exists(S(0))) File.Delete(S(0));
            return Value.Null();
        case "list_files": {
            var result = Value.NewList();
            string dir = S(0);
            if (Directory.Exists(dir))
                foreach (var f in Directory.GetFiles(dir))
                    result.List!.Add(Value.Str(f));
            return result;
        }
        case "list_dirs": {
            var result = Value.NewList();
            string dir = S(0);
            if (Directory.Exists(dir))
                foreach (var d in Directory.GetDirectories(dir))
                    result.List!.Add(Value.Str(d));
            return result;
        }
        case "get_cwd":
            return Value.Str(Directory.GetCurrentDirectory());
        case "set_cwd":
            Directory.SetCurrentDirectory(S(0));
            return Value.Null();
        case "exit":
            System.Environment.Exit((int)L(0));
            return Value.Null();
        case "sleep":
            Thread.Sleep((int)(D(0) * 1000));
            return Value.Null();
        case "time":
            return Value.Float((double)DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() / 1000.0);
        case "timestamp":
            return Value.Int(DateTimeOffset.UtcNow.ToUnixTimeSeconds());
        case "format_int": {
            string fmt = "{0," + L(1) + "}";
            return Value.Str(string.Format(fmt, L(0)));
        }
        case "format_float": {
            string fmt = "F" + L(1);
            return Value.Str(D(0).ToString(fmt));
        }
        case "format_string": {
            string s = S(0);
            int width = (int)L(1);
            return Value.Str(s.PadRight(width));
        }
        case "printf": {
            string fmt = S(0);
            var fmtArgs = args.Count > 1 ? args[1] : Value.NewList();
            Console.Write(FormatString(fmt, fmtArgs));
            return Value.Null();
        }
        case "sprintf": {
            string fmt = S(0);
            var fmtArgs = args.Count > 1 ? args[1] : Value.NewList();
            return Value.Str(FormatString(fmt, fmtArgs));
        }

        // Type
        case "to_int": {
            var v = A(0);
            if (v.Type == VType.Int)    return v;
            if (v.Type == VType.Float)  return Value.Int((long)v.FVal);
            if (v.Type == VType.Bool)   return Value.Int(v.IVal);
            if (v.Type == VType.String && long.TryParse(v.SVal, out long iv)) return Value.Int(iv);
            if (v.Type == VType.String && double.TryParse(v.SVal, out double fv)) return Value.Int((long)fv);
            return Value.Int(0);
        }
        case "to_float": {
            var v = A(0);
            if (v.Type == VType.Float)  return v;
            if (v.Type == VType.Int)    return Value.Float((double)v.IVal);
            if (v.Type == VType.Bool)   return Value.Float(v.IVal);
            if (v.Type == VType.String && double.TryParse(v.SVal, out double fv)) return Value.Float(fv);
            return Value.Float(0);
        }
        case "to_string":
            return Value.Str(A(0).ToString());
        case "is_int":
            return Value.Bool(A(0).Type == VType.Int);
        case "is_float":
            return Value.Bool(A(0).Type == VType.Float);
        case "is_string":
            return Value.Bool(A(0).Type == VType.String);
        case "is_list":
            return Value.Bool(A(0).Type == VType.List);
        case "is_bool":
            return Value.Bool(A(0).Type == VType.Bool);

        // String
        case "repeat_str": {
            var sb = new StringBuilder();
            for (long i = 0; i < L(1); i++) sb.Append(S(0));
            return Value.Str(sb.ToString());
        }
        case "contains":
        case "str_contains":
            return Value.Bool(S(0).Contains(S(1)));
        case "startswith":
        case "str_starts_with":
            return Value.Bool(S(0).StartsWith(S(1)));
        case "endswith":
        case "str_ends_with":
            return Value.Bool(S(0).EndsWith(S(1)));
        case "isempty":
        case "str_is_empty":
            return Value.Bool(string.IsNullOrEmpty(S(0)));
        case "str_reverse":
            return Value.Str(new string(S(0).Reverse().ToArray()));
        case "str_count": {
            string src = S(0); string ch = S(1);
            int count = 0; int idx = 0;
            while ((idx = src.IndexOf(ch, idx, StringComparison.Ordinal)) >= 0) { count++; idx += ch.Length; }
            return Value.Int(count);
        }
        case "str_join": {
            var lst = A(0);
            if (lst.Type != VType.List) throw new Exception("str_join: first arg must be a list");
            return Value.Str(string.Join(S(1), lst.List!.Select(v => v.ToString())));
        }
        case "str_pad_left":
            return Value.Str(S(0).PadLeft((int)L(1), S(2).Length > 0 ? S(2)[0] : ' '));
        case "str_pad_right":
            return Value.Str(S(0).PadRight((int)L(1), S(2).Length > 0 ? S(2)[0] : ' '));
        case "str_len":
            return Value.Int(S(0).Length);
        case "str_concat":
            return Value.Str(S(0) + S(1));
        case "str_repeat": {
            var sb = new StringBuilder();
            for (long i = 0; i < L(1); i++) sb.Append(S(0));
            return Value.Str(sb.ToString());
        }
        case "str_indexof":
            return Value.Int(S(0).IndexOf(S(1), StringComparison.Ordinal));
        case "str_replace":
            return Value.Str(S(0).Replace(S(1), S(2)));
        case "substring": {
            string src = S(0); int start = (int)L(1); int len = (int)L(2);
            if (start >= src.Length) return Value.Str("");
            len = Math.Min(len, src.Length - start);
            return Value.Str(src.Substring(start, len));
        }
        case "split": {
            string src = S(0); string delim = S(1);
            var parts = src.Split(new[] { delim }, StringSplitOptions.None);
            var result = Value.NewList();
            foreach (var p in parts) result.List!.Add(Value.Str(p));
            return result;
        }
        case "trim":
            return Value.Str(S(0).Trim());
        case "to_upper":
            return Value.Str(S(0).ToUpper());
        case "to_lower":
            return Value.Str(S(0).ToLower());

        // List
        case "list_get": {
            var lst = A(0); int idx = (int)L(1);
            if (lst.Type != VType.List) throw new Exception("list_get: not a list");
            return lst.List![NormalizeIndex(idx, lst.List.Count)].Copy();
        }
        case "list_first": {
            var lst = A(0);
            if (lst.Type != VType.List || lst.List!.Count == 0) throw new Exception("list_first: empty list");
            return lst.List![0].Copy();
        }
        case "list_last": {
            var lst = A(0);
            if (lst.Type != VType.List || lst.List!.Count == 0) throw new Exception("list_last: empty list");
            return lst.List![^1].Copy();
        }
        case "list_contains": {
            var lst = A(0); var val = A(1);
            if (lst.Type != VType.List) throw new Exception("list_contains: not a list");
            return Value.Bool(lst.List!.Any(v => ValEq(v, val)));
        }
        case "list_indexof": {
            var lst = A(0); var val = A(1);
            if (lst.Type != VType.List) throw new Exception("list_indexof: not a list");
            for (int i = 0; i < lst.List!.Count; i++)
                if (ValEq(lst.List[i], val)) return Value.Int(i);
            return Value.Int(-1);
        }
        case "list_count": {
            var lst = A(0); var val = A(1);
            if (lst.Type != VType.List) throw new Exception("list_count: not a list");
            return Value.Int(lst.List!.Count(v => ValEq(v, val)));
        }
        case "list_sum": {
            var lst = A(0);
            if (lst.Type != VType.List) throw new Exception("list_sum: not a list");
            bool hasFloat = lst.List!.Any(v => v.Type == VType.Float);
            if (hasFloat) return Value.Float(lst.List!.Sum(v => v.Type == VType.Float ? v.FVal : v.IVal));
            return Value.Int(lst.List!.Sum(v => v.IVal));
        }
        case "list_max": {
            var lst = A(0);
            if (lst.Type != VType.List || lst.List!.Count == 0) throw new Exception("list_max: empty list");
            var best = lst.List![0];
            foreach (var v in lst.List!) if (ValCmp(v, best) > 0) best = v;
            return best.Copy();
        }
        case "list_min": {
            var lst = A(0);
            if (lst.Type != VType.List || lst.List!.Count == 0) throw new Exception("list_min: empty list");
            var best = lst.List![0];
            foreach (var v in lst.List!) if (ValCmp(v, best) < 0) best = v;
            return best.Copy();
        }
        case "list_reverse": {
            var lst = A(0);
            if (lst.Type != VType.List) throw new Exception("list_reverse: not a list");
            var result = Value.NewList();
            for (int i = lst.List!.Count - 1; i >= 0; i--)
                result.List!.Add(lst.List[i].Copy());
            return result;
        }
        case "list_copy": {
            var lst = A(0);
            if (lst.Type != VType.List) throw new Exception("list_copy: not a list");
            return lst.Copy();
        }
        case "list_concat": {
            var a = A(0); var b = A(1);
            if (a.Type != VType.List || b.Type != VType.List) throw new Exception("list_concat: not lists");
            var result = Value.NewList();
            foreach (var v in a.List!) result.List!.Add(v.Copy());
            foreach (var v in b.List!) result.List!.Add(v.Copy());
            return result;
        }
        case "list_fill": {
            var val = A(0); long n = L(1);
            var result = Value.NewList();
            for (long i = 0; i < n; i++) result.List!.Add(val.Copy());
            return result;
        }
        case "list_range": {
            long start = L(0); long stop = L(1);
            var result = Value.NewList();
            for (long i = start; i < stop; i++) result.List!.Add(Value.Int(i));
            return result;
        }
        case "list_swap": {
            var lst = A(0); int ai = (int)L(1); int bi = (int)L(2);
            if (lst.Type != VType.List) throw new Exception("list_swap: not a list");
            ai = NormalizeIndex(ai, lst.List!.Count);
            bi = NormalizeIndex(bi, lst.List!.Count);
            (lst.List![ai], lst.List![bi]) = (lst.List![bi], lst.List![ai]);
            return Value.Null();
        }
        case "list_sort": {
            var lst = A(0);
            if (lst.Type != VType.List) throw new Exception("list_sort: not a list");
            var sorted = lst.Copy();
            sorted.List!.Sort((x, y) => Math.Sign(ValCmp(x, y)));
            return sorted;
        }
        case "list_unique": {
            var lst = A(0);
            if (lst.Type != VType.List) throw new Exception("list_unique: not a list");
            var result = Value.NewList();
            foreach (var v in lst.List!)
                if (!result.List!.Any(x => ValEq(x, v)))
                    result.List!.Add(v.Copy());
            return result;
        }

        // Math
        case "pi":  return Value.Float(Math.PI);
        case "e":   return Value.Float(Math.E);
        case "tau": return Value.Float(Math.Tau);
        case "phi": return Value.Float(1.6180339887498948482);
        case "inf": return Value.Float(double.PositiveInfinity);

        // Math
        case "abs":
        case "sign": return Value.Int(Math.Sign(D(0)));
        case "max":  return ValCmp(A(0), A(1)) >= 0 ? A(0).Copy() : A(1).Copy();
        case "min":  return ValCmp(A(0), A(1)) <= 0 ? A(0).Copy() : A(1).Copy();
        case "clamp": {
            if (ValCmp(A(0), A(1)) < 0) return A(1).Copy();
            if (ValCmp(A(0), A(2)) > 0) return A(2).Copy();
            return A(0).Copy();
        }
        case "saturate": {
            double v = D(0);
            return Value.Float(Math.Clamp(v, 0.0, 1.0));
        }
        case "mod":    return Value.Int(L(0) % L(1));
        case "is_even": return Value.Bool(L(0) % 2 == 0);
        case "is_odd":  return Value.Bool(L(0) % 2 != 0);
        case "is_pos":  return Value.Bool(D(0) > 0);
        case "is_neg":  return Value.Bool(D(0) < 0);
        case "is_zero": return Value.Bool(D(0) == 0);
        case "wrap": {
            double val = D(0), lo = D(1), hi = D(2);
            double range = hi - lo;
            double r = (val - lo) % range;
            if (r < 0) r += range;
            return Value.Float(r + lo);
        }

        // Math
        case "floor": return A(0).Type == VType.Int ? A(0).Copy() : Value.Float(Math.Floor(D(0)));
        case "ceil":  return A(0).Type == VType.Int ? A(0).Copy() : Value.Float(Math.Ceiling(D(0)));
        case "round": return A(0).Type == VType.Int ? A(0).Copy() : Value.Float(Math.Round(D(0), MidpointRounding.AwayFromZero));
        case "round_to": return Value.Float(Math.Round(D(0), (int)L(1), MidpointRounding.AwayFromZero));
        case "trunc": return Value.Float(Math.Truncate(D(0)));
        case "frac":  return Value.Float(D(0) - Math.Truncate(D(0)));

        // Math
        case "pow":   return Value.Float(Math.Pow(D(0), D(1)));
        case "sqrt":  return Value.Float(Math.Sqrt(D(0)));
        case "cbrt":  return Value.Float(Math.Cbrt(D(0)));
        case "nroot": return Value.Float(Math.Pow(D(0), 1.0 / D(1)));
        case "hypot": return Value.Float(Math.Sqrt(D(0)*D(0) + D(1)*D(1)));

        // Math
        case "ln":       return Value.Float(Math.Log(D(0)));
        case "log2":     return Value.Float(Math.Log2(D(0)));
        case "log10":    return Value.Float(Math.Log10(D(0)));
        case "log_base": return Value.Float(Math.Log(D(0), D(1)));
        case "exp":      return Value.Float(Math.Exp(D(0)));

        // Math
        case "sin":        return Value.Float(Math.Sin(D(0)));
        case "cos":        return Value.Float(Math.Cos(D(0)));
        case "tan":        return Value.Float(Math.Tan(D(0)));
        case "atan":       return Value.Float(Math.Atan(D(0)));
        case "atan2":      return Value.Float(Math.Atan2(D(0), D(1)));
        case "acos":       return Value.Float(Math.Acos(D(0)));
        case "deg_to_rad": return Value.Float(D(0) * Math.PI / 180.0);
        case "rad_to_deg": return Value.Float(D(0) * 180.0 / Math.PI);

        // Math
        case "gcd": {
            long a = Math.Abs(L(0)), b = Math.Abs(L(1));
            while (b > 0) { long t = b; b = a % b; a = t; }
            return Value.Int(a);
        }
        case "lcm": {
            long a = Math.Abs(L(0)), b = Math.Abs(L(1));
            if (a == 0 || b == 0) return Value.Int(0);
            long g = a; long tmp = b;
            while (tmp > 0) { long t = tmp; tmp = g % tmp; g = t; }
            return Value.Int(a / g * b);
        }
        case "isprime": {
            long n = L(0);
            if (n < 2) return Value.Bool(false);
            if (n == 2) return Value.Bool(true);
            if (n % 2 == 0) return Value.Bool(false);
            for (long i = 3; i * i <= n; i += 2)
                if (n % i == 0) return Value.Bool(false);
            return Value.Bool(true);
        }
        case "factorial": {
            long n = L(0);
            if (n < 0) return Value.Int(-1);
            long r = 1;
            for (long i = 2; i <= n; i++) r *= i;
            return Value.Int(r);
        }
        case "choose": {
            long n = L(0), k = L(1);
            if (k > n) return Value.Int(0);
            if (k == 0 || k == n) return Value.Int(1);
            if (k > n - k) k = n - k;
            long r = 1;
            for (long i = 0; i < k; i++) r = r * (n - i) / (i + 1);
            return Value.Int(r);
        }
        case "fib": {
            long n = L(0);
            if (n <= 0) return Value.Int(0);
            if (n == 1) return Value.Int(1);
            long a = 0, b = 1;
            for (long i = 2; i <= n; i++) { long t = a + b; a = b; b = t; }
            return Value.Int(b);
        }

        //  list math 
        case "sum": {
            var lst = A(0);
            if (lst.Type != VType.List) throw new Exception("sum: not a list");
            bool hasFloat = lst.List!.Any(v => v.Type == VType.Float);
            if (hasFloat) return Value.Float(lst.List!.Sum(v => v.Type == VType.Float ? v.FVal : v.IVal));
            return Value.Int(lst.List!.Sum(v => v.IVal));
        }
        case "product": {
            var lst = A(0);
            if (lst.Type != VType.List) throw new Exception("product: not a list");
            double r = 1;
            foreach (var v in lst.List!) r *= v.Type == VType.Float ? v.FVal : v.IVal;
            return Value.Float(r);
        }
        case "average": {
            var lst = A(0);
            if (lst.Type != VType.List || lst.List!.Count == 0) return Value.Int(0);
            double s = lst.List!.Sum(v => v.Type == VType.Float ? v.FVal : v.IVal);
            return Value.Float(s / lst.List!.Count);
        }
        case "sumsq": {
            var lst = A(0);
            if (lst.Type != VType.List) throw new Exception("sumsq: not a list");
            double s = 0;
            foreach (var v in lst.List!) { double x = v.Type == VType.Float ? v.FVal : v.IVal; s += x * x; }
            return Value.Float(s);
        }
        case "variance": {
            var lst = A(0);
            if (lst.Type != VType.List || lst.List!.Count == 0) return Value.Int(0);
            double avg = lst.List!.Average(v => v.Type == VType.Float ? v.FVal : v.IVal);
            double s = lst.List!.Sum(v => { double d = (v.Type == VType.Float ? v.FVal : v.IVal) - avg; return d * d; });
            return Value.Float(s / lst.List!.Count);
        }
        case "stddev": {
            var lst = A(0);
            if (lst.Type != VType.List || lst.List!.Count == 0) return Value.Int(0);
            double avg = lst.List!.Average(v => v.Type == VType.Float ? v.FVal : v.IVal);
            double s = lst.List!.Sum(v => { double d = (v.Type == VType.Float ? v.FVal : v.IVal) - avg; return d * d; });
            return Value.Float(Math.Sqrt(s / lst.List!.Count));
        }
        case "dot": {
            var la = A(0); var lb = A(1);
            if (la.Type != VType.List || lb.Type != VType.List) throw new Exception("dot: not lists");
            double s = 0;
            int len = Math.Min(la.List!.Count, lb.List!.Count);
            for (int i = 0; i < len; i++) {
                double x = la.List[i].Type == VType.Float ? la.List[i].FVal : la.List[i].IVal;
                double y = lb.List[i].Type == VType.Float ? lb.List[i].FVal : lb.List[i].IVal;
                s += x * y;
            }
            return Value.Float(s);
        }
        case "lerp":  return Value.Float(D(0) + (D(1) - D(0)) * D(2));
        case "remap": return Value.Float(D(3) + (D(0) - D(1)) / (D(2) - D(1)) * (D(4) - D(3)));

        default:
            throw new Exception($"Unknown built-in '{name}'");
        }
    }

    // sprintf/printf helper: replaces {} placeholders with list items
    static string FormatString(string fmt, Value argsVal) {
        var parts = fmt.Split("{}");
        var sb = new StringBuilder();
        var lst = argsVal.Type == VType.List ? argsVal.List! : new List<Value> { argsVal };
        for (int i = 0; i < parts.Length; i++) {
            sb.Append(parts[i]);
            if (i < lst.Count) sb.Append(lst[i]);
        }
        return sb.ToString();
    }

    //  Module loading 

    void LoadPlugin(string moduleName) {
        if (_linkedPlugins.Contains(moduleName)) return;
        _linkedPlugins.Add(moduleName);

        string pluginPath = $"plugins/{moduleName}.gsl";
        if (File.Exists(pluginPath)) { LoadModuleFromFile(pluginPath); return; }

        string stdPath = $"std/{moduleName}.gsl";
        if (File.Exists(stdPath)) { LoadModuleFromFile(stdPath); return; }

        Console.WriteLine($"Warning: Plugin '{moduleName}' not found");
    }

    void LoadModuleFromFile(string path) {
        try {
            string src  = File.ReadAllText(path);
            var tokens  = new Lexer(src).TokenizeAll();
            var ast     = new Parser(tokens).Parse();
            string mod  = Path.GetFileNameWithoutExtension(path);
            foreach (var stmt in ast.Stmts!) {
                if (stmt is CraftStmt craft && craft.Name != null) {
                    _funcs[craft.Name] = craft;
                    if (path.StartsWith("std/")) _stdFunctionMap[craft.Name] = mod;
                }
            }
            ExecBlock(ast.Stmts!, _global);
        } catch (Exception ex) {
            throw new Exception($"Error loading module '{path}': {ex.Message}");
        }
    }

    bool TryLoadStdModuleForFunction(string funcName) {
        if (_stdFunctionMap.TryGetValue(funcName, out var moduleName)) {
            if (!_loadedStdModules.Contains(moduleName)) {
                _loadedStdModules.Add(moduleName);
                string stdPath = $"std/{moduleName}.gsl";
                if (File.Exists(stdPath)) { LoadModuleFromFile(stdPath); return true; }
            }
        }
        if (!Directory.Exists("std/")) return false;
        var allStdFiles = Directory.GetFiles("std/", "*.gsl");
        if (_loadedStdModules.Count < allStdFiles.Length) {
            foreach (var sf in allStdFiles) {
                string stdModuleName = Path.GetFileNameWithoutExtension(sf);
                if (_loadedStdModules.Contains(stdModuleName)) continue;
                try {
                    string src = File.ReadAllText(sf);
                    if (src.Contains($"craft {funcName}(") || src.Contains($"global craft {funcName}(")) {
                        _loadedStdModules.Add(stdModuleName);
                        LoadModuleFromFile(sf);
                        return true;
                    }
                } catch { }
            }
        }
        return false;
    }

    //  Execution 

    void ExecBlock(List<Node> stmts, Env env) {
        foreach (var stmt in stmts) Exec(stmt, env);
    }

    void Exec(Node node, Env env) {
        switch (node) {
            case LinkStmt: break;

            case MakeStmt m:
                env.Define(m.Name!, Eval(m.Value!, env));
                break;

            case AssignStmt a:
                env.Set(a.Name!, Eval(a.Value!, env));
                break;

            case CompoundAssignStmt ca: {
                var cur = env.Get(ca.Name!);
                var rhs = Eval(ca.Value!, env);
                Value result = ca.Op switch {
                    TType.PLUSEQ  => AddValues(cur, rhs),
                    TType.MINUSEQ => ArithValues(cur, rhs, TType.MINUS),
                    TType.STAREQ  => ArithValues(cur, rhs, TType.STAR),
                    TType.SLASHEQ => ArithValues(cur, rhs, TType.SLASH),
                    _ => throw new Exception($"Unknown compound op {ca.Op}")
                };
                env.Set(ca.Name!, result);
                break;
            }

            case IndexAssignStmt ia: {
                var container = env.Get(ia.Name!);
                var idx       = Eval(ia.Idx!, env);
                var val       = Eval(ia.Value!, env);
                if (container.Type == VType.List) {
                    int i = NormalizeIndex((int)idx.IVal, container.List!.Count);
                    container.List![i] = val.Copy();
                } else if (container.Type == VType.Map) {
                    container.Map![idx.ToString()] = val.Copy();
                } else {
                    throw new Exception($"'{ia.Name}' is not a list or map");
                }
                break;
            }

            case SayStmt s:
                Console.WriteLine(Eval(s.Expr!, env).ToString());
                break;

            case PauseStmt p: {
                var v    = Eval(p.Expr!, env);
                double s = v.Type == VType.Float ? v.FVal : v.IVal;
                Thread.Sleep((int)(s * 1000));
                break;
            }

            case PushinStmt pi: {
                var list = env.Get(pi.Name!);
                if (list.Type != VType.List) throw new Exception($"'{pi.Name}' is not a list");
                list.List!.Add(Eval(pi.Value!, env).Copy());
                break;
            }

            case PulloutStmt po: {
                var list = env.Get(po.Name!);
                var idx  = Eval(po.Idx!, env);
                if (list.Type != VType.List) throw new Exception($"'{po.Name}' is not a list");
                int i = NormalizeIndex((int)idx.IVal, list.List!.Count);
                list.List!.RemoveAt(i);
                break;
            }

            case GiveStmt g:
                throw new ReturnException(Eval(g.Expr!, env));

            case StopStmt:
                throw new StopException();

            case SkipStmt:
                throw new SkipException();

            case CallStmt cs: {
                var cargs = new List<Value>();
                foreach (var a in cs.Args!) cargs.Add(Eval(a, env));
                CallFunc(cs.Name!, cargs, env);
                break;
            }

            case CheckStmt ch: {
                bool hit = false;
                foreach (var (cond, body) in ch.Cases!) {
                    if (!hit && Eval(cond, env).Truthy()) {
                        ExecBlock(body, new Env(env));
                        hit = true;
                    }
                }
                if (!hit && ch.Otherwise != null)
                    ExecBlock(ch.Otherwise, new Env(env));
                break;
            }

            case CycleStmt cy: {
                var cv    = Eval(cy.Count!, env);
                long count = cv.Type == VType.Int ? cv.IVal : (long)cv.FVal;
                for (long i = 0; i < count; i++) {
                    try { ExecBlock(cy.Body!, new Env(env)); }
                    catch (StopException) { break; }
                    catch (SkipException) { continue; }
                }
                break;
            }

            case SpinStmt sp:
                while (Eval(sp.Cond!, env).Truthy()) {
                    try { ExecBlock(sp.Body!, new Env(env)); }
                    catch (StopException) { break; }
                    catch (SkipException) { continue; }
                }
                break;

            case ForeachStmt fe: {
                var listVal = Eval(fe.List!, env);
                if (listVal.Type == VType.List) {
                    foreach (var item in listVal.List!) {
                        var loopEnv = new Env(env);
                        loopEnv.Define(fe.Var!, item.Copy());
                        try { ExecBlock(fe.Body!, loopEnv); }
                        catch (StopException) { break; }
                        catch (SkipException) { continue; }
                    }
                } else if (listVal.Type == VType.Map) {
                    foreach (var kv in listVal.Map!) {
                        var loopEnv = new Env(env);
                        var pair = Value.NewList();
                        pair.List!.Add(Value.Str(kv.Key));
                        pair.List!.Add(kv.Value.Copy());
                        loopEnv.Define(fe.Var!, pair);
                        try { ExecBlock(fe.Body!, loopEnv); }
                        catch (StopException) { break; }
                        catch (SkipException) { continue; }
                    }
                } else if (listVal.Type == VType.String) {
                    foreach (char ch in listVal.SVal!) {
                        var loopEnv = new Env(env);
                        loopEnv.Define(fe.Var!, Value.Str(ch.ToString()));
                        try { ExecBlock(fe.Body!, loopEnv); }
                        catch (StopException) { break; }
                        catch (SkipException) { continue; }
                    }
                } else {
                    throw new Exception("foreach requires a list, map, or string");
                }
                break;
            }

            case CraftStmt cr:
                _funcs[cr.Name!] = cr;
                break;

            default:
                Eval(node, env);
                break;
        }
    }

    //  Evaluation 

    Value Eval(Node node, Env env) {
        switch (node) {
            case NumberNode n:
                return n.Tok!.Type == TType.FLOAT
                    ? Value.Float(n.Tok.FVal)
                    : Value.Int(n.Tok.IVal);

            case StringNode s:
                return Value.Str(s.Tok!.Raw);

            case BoolNode b:
                return Value.Bool(b.Val);

            case IdentNode id:
                return env.Get(id.Name!).Copy();

            case PackNode pk: {
                var list = Value.NewList();
                foreach (var item in pk.Items!) list.List!.Add(Eval(item, env).Copy());
                return list;
            }

            case MapNode mn: {
                var map = Value.NewMap();
                foreach (var (k, v) in mn.Pairs!) {
                    var key = Eval(k, env).ToString();
                    map.Map![key] = Eval(v, env).Copy();
                }
                return map;
            }

            case IndexNode ix: {
                var obj = Eval(ix.Obj!, env);
                var idx = Eval(ix.Idx!, env);
                if (obj.Type == VType.List) {
                    int i = NormalizeIndex((int)idx.IVal, obj.List!.Count);
                    return obj.List![i].Copy();
                }
                if (obj.Type == VType.String) {
                    int i = NormalizeIndex((int)idx.IVal, obj.SVal!.Length);
                    return Value.Str(obj.SVal![i].ToString());
                }
                if (obj.Type == VType.Map) {
                    string key = idx.ToString();
                    if (!obj.Map!.TryGetValue(key, out var mv))
                        throw new Exception($"Map key '{key}' not found");
                    return mv.Copy();
                }
                throw new Exception("Cannot index non-list/string/map");
            }

            case AskNode ask: {
                var prompt = Eval(ask.Prompt!, env);
                Console.Write(prompt.ToString() + " ");
                string inp = Console.ReadLine() ?? "";
                if (long.TryParse(inp, out long iv))     return Value.Int(iv);
                if (double.TryParse(inp, out double fv)) return Value.Float(fv);
                return Value.Str(inp);
            }

            case CalcNode calc:
                return Eval(calc.Expr!, env);

            case SizeofNode sz: {
                var v = Eval(sz.Expr!, env);
                if (v.Type == VType.List)   return Value.Int(v.List!.Count);
                if (v.Type == VType.String) return Value.Int(v.SVal!.Length);
                if (v.Type == VType.Map)    return Value.Int(v.Map!.Count);
                throw new Exception("sizeof requires list, map, or string");
            }

            case KindofNode kd:
                return Value.Str(Eval(kd.Expr!, env).KindOf());

            case RandNode rnd: {
                var mn = Eval(rnd.Min!, env);
                var mx = Eval(rnd.Max!, env);
                long lo = mn.Type == VType.Int ? mn.IVal : (long)mn.FVal;
                long hi = mx.Type == VType.Int ? mx.IVal : (long)mx.FVal;
                return Value.Int(_rng.NextInt64(lo, hi + 1));
            }

            case CallNode cn: {
                var cargs = new List<Value>();
                foreach (var a in cn.Args!) cargs.Add(Eval(a, env));
                return CallFunc(cn.Name!, cargs, env);
            }

            case BinOpNode b:
                return EvalBinOp(b, env);

            case UnOpNode u: {
                var v = Eval(u.Operand!, env);
                if (u.Op == TType.MINUS)
                    return v.Type == VType.Float ? Value.Float(-v.FVal) : Value.Int(-v.IVal);
                if (u.Op == TType.NOT)
                    return Value.Bool(!v.Truthy());
                throw new Exception($"Unknown unary op {u.Op}");
            }

            default:
                Exec(node, env);
                return Value.Null();
        }
    }

    Value EvalBinOp(BinOpNode b, Env env) {
        if (b.Op == TType.AND) {
            var l = Eval(b.Left!, env);
            return l.Truthy() ? Eval(b.Right!, env) : l;
        }
        if (b.Op == TType.OR) {
            var l = Eval(b.Left!, env);
            return l.Truthy() ? l : Eval(b.Right!, env);
        }

        var left  = Eval(b.Left!,  env);
        var right = Eval(b.Right!, env);

        switch (b.Op) {
            case TType.PLUS:    return AddValues(left, right);
            case TType.MINUS:   return ArithValues(left, right, TType.MINUS);
            case TType.STAR:    return ArithValues(left, right, TType.STAR);
            case TType.SLASH:   return ArithValues(left, right, TType.SLASH);
            case TType.PERCENT:
                if (right.IVal == 0) throw new Exception("Modulo by zero");
                return Value.Int(left.IVal % right.IVal);
            case TType.EQEQ: return Value.Bool(ValEq(left, right));
            case TType.NEQ:  return Value.Bool(!ValEq(left, right));
            case TType.LT:   return Value.Bool(ValCmp(left, right) < 0);
            case TType.GT:   return Value.Bool(ValCmp(left, right) > 0);
            case TType.LTE:  return Value.Bool(ValCmp(left, right) <= 0);
            case TType.GTE:  return Value.Bool(ValCmp(left, right) >= 0);
            default:
                throw new Exception($"Unknown operator {b.Op}");
        }
    }

    //  Helpers 

    static int NormalizeIndex(int i, int len) {
        if (i < 0) i = len + i;
        if (i < 0 || i >= len) throw new Exception("Index out of range");
        return i;
    }

    Value AddValues(Value left, Value right) {
        if (left.Type == VType.String || right.Type == VType.String)
            return Value.Str(left.ToString() + right.ToString());
        if (left.Type == VType.Float || right.Type == VType.Float)
            return Value.Float(left.FVal + right.FVal);
        return Value.Int(left.IVal + right.IVal);
    }

    Value ArithValues(Value left, Value right, TType op) {
        switch (op) {
            case TType.MINUS:
                if (left.Type == VType.Float || right.Type == VType.Float)
                    return Value.Float(left.FVal - right.FVal);
                return Value.Int(left.IVal - right.IVal);
            case TType.STAR:
                if (left.Type == VType.Float || right.Type == VType.Float)
                    return Value.Float(left.FVal * right.FVal);
                return Value.Int(left.IVal * right.IVal);
            case TType.SLASH:
                if (right.FVal == 0 && right.IVal == 0) throw new Exception("Division by zero");
                return Value.Float(left.FVal / right.FVal);
            default:
                throw new Exception($"Unknown arith op {op}");
        }
    }

    Value CallFunc(string name, List<Value> args, Env callEnv) {
        if (_builtins.Contains(name))
            return CallBuiltin(name, args);

        if (!_funcs.ContainsKey(name))
            TryLoadStdModuleForFunction(name);

        if (!_funcs.TryGetValue(name, out var fn))
            throw new Exception($"Function '{name}' not defined");

        var scope = new Env(_global);
        for (int i = 0; i < fn.Params!.Count && i < args.Count; i++)
            scope.Define(fn.Params[i], args[i].Copy());

        try {
            ExecBlock(fn.Body!, scope);
        } catch (ReturnException r) {
            return r.Val;
        }

        return Value.Null();
    }

    bool ValEq(Value a, Value b) {
        if (a.Type == VType.Null && b.Type == VType.Null) return true;
        if (a.Type == VType.String && b.Type == VType.String) return a.SVal == b.SVal;
        if (a.Type == VType.Bool   && b.Type == VType.Bool)   return a.IVal == b.IVal;
        return ValNum(a) == ValNum(b);
    }

    double ValNum(Value v) => v.Type == VType.Float ? v.FVal : v.IVal;

    double ValCmp(Value a, Value b) {
        if (a.Type == VType.String && b.Type == VType.String)
            return string.Compare(a.SVal, b.SVal, StringComparison.Ordinal);
        return ValNum(a) - ValNum(b);
    }
}