using System;
using System.Collections.Generic;
using System.Text;

class Lexer {
    readonly string _src;
    int _pos;
    int _line = 1;

    static readonly Dictionary<string, TType> KwMap = new() {
        {"make",      TType.MAKE},
        {"say",       TType.SAY},
        {"ask",       TType.ASK},
        {"calc",      TType.CALC},
        {"check",     TType.CHECK},
        {"branch",    TType.BRANCH},
        {"otherwise", TType.OTHERWISE},
        {"cycle",     TType.CYCLE},
        {"spin",      TType.SPIN},
        {"foreach",   TType.FOREACH},
        {"in",        TType.IN},
        {"craft",     TType.CRAFT},
        {"give",      TType.GIVE},
        {"pack",      TType.PACK},
        {"pushin",    TType.PUSHIN},
        {"pullout",   TType.PULLOUT},
        {"sizeof",    TType.SIZEOF},
        {"kindof",    TType.KINDOF},
        {"rand",      TType.RAND},
        {"pause",     TType.PAUSE},
        {"stop",      TType.STOP},
        {"skip",      TType.SKIP},
        {"true",      TType.TRUE},
        {"false",     TType.FALSE},
        {"and",       TType.AND},
        {"or",        TType.OR},
        {"not",       TType.NOT},
        {"link",      TType.LINK},
        {"global",    TType.GLOBAL}
    };

    public Lexer(string src) { _src = src; }

    char Cur  => _pos   < _src.Length ? _src[_pos]   : '\0';
    char Next => _pos+1 < _src.Length ? _src[_pos+1] : '\0';
    void Adv() => _pos++;
    void Err(string msg) => throw new Exception($"[Line {_line}] Lex error: {msg}");

    public List<Token> Tokenize() {
        var toks = new List<Token>();

        while (_pos < _src.Length) {
            char c = Cur;

            if (c == '\n') { _line++; Adv(); continue; }
            if (c == ' ' || c == '\t' || c == '\r') { Adv(); continue; }
            if (c == '#') { while (_pos < _src.Length && Cur != '\n') Adv(); continue; }

            if (c == '"' || c == '\'') { toks.Add(ReadString(c)); continue; }

            if (char.IsDigit(c) || (c == '-' && char.IsDigit(Next) && IsExprStart(toks))) {
                toks.Add(ReadNumber()); continue;
            }

            if (char.IsLetter(c) || c == '_') { toks.Add(ReadIdent()); continue; }

            var sym = ReadSymbol();
            if (sym != null) { toks.Add(sym); continue; }

            Err($"Unknown character '{c}'");
        }

        toks.Add(new Token(TType.EOF, "<eof>", 0, 0, _line));
        return toks;
    }

    // Reads a string literal, supporting {varname} interpolation.
    // Interpolated segments are emitted as: STRING + PLUS + IDENT/expr + PLUS + STRING ...
    // We handle this by returning a synthetic interp marker token and letting the parser
    // deal with it, OR we can expand here into multiple tokens.
    // Simplest approach: expand interpolation into token stream directly.
    Token ReadString(char quote) {
        Adv();
        var sb        = new StringBuilder();
        var result    = new List<Token>();
        int startLine = _line;

        while (_pos < _src.Length && Cur != quote) {
            // String interpolation: {expr}
            if (Cur == '{' && quote == '"') {
                // flush current literal segment
                if (sb.Length > 0) {
                    result.Add(new Token(TType.STRING, sb.ToString(), 0, 0, _line));
                    result.Add(new Token(TType.PLUS, "+", 0, 0, _line));
                    sb.Clear();
                }
                Adv(); // consume '{'
                var exprSb = new StringBuilder();
                int depth  = 1;
                while (_pos < _src.Length && depth > 0) {
                    if (Cur == '{') depth++;
                    else if (Cur == '}') { depth--; if (depth == 0) { Adv(); break; } }
                    exprSb.Append(Cur); Adv();
                }
                // Lex the inner expression and append tokens
                string innerSrc = exprSb.ToString();
                var innerTokens = new Lexer(innerSrc).Tokenize();
                // innerTokens ends with EOF — skip it
                // Wrap in str() cast via kindof trick — actually just emit a STRCAST marker.
                // We prepend a TOSTR intrinsic: emit as __tostr( <inner tokens> )
                result.Add(new Token(TType.IDENT, "__tostr", 0, 0, _line));
                result.Add(new Token(TType.LPAREN, "(", 0, 0, _line));
                for (int k = 0; k < innerTokens.Count - 1; k++)
                    result.Add(innerTokens[k]);
                result.Add(new Token(TType.RPAREN, ")", 0, 0, _line));
                result.Add(new Token(TType.PLUS, "+", 0, 0, _line));
                continue;
            }

            if (Cur == '\\') {
                Adv();
                sb.Append(Cur switch {
                    'n'  => '\n',
                    't'  => '\t',
                    '\\' => '\\',
                    '"'  => '"',
                    '\'' => '\'',
                    var x => x
                });
            } else {
                sb.Append(Cur);
            }
            Adv();
        }
        if (Cur != quote) Err("Unterminated string");
        Adv();

        // If we collected interpolation tokens, return a special multi-token via a trick:
        // We stash extras in _pendingTokens and return the first one.
        string tail = sb.ToString();
        if (result.Count > 0) {
            // append trailing literal
            result.Add(new Token(TType.STRING, tail, 0, 0, _line));
            // remove trailing PLUS if last real token before final STRING was PLUS
            // Actually the structure is fine: STR + __tostr(...) + STR
            // But we need to return all these tokens. We use _pendingTokens.
            foreach (var tok in result) _pendingTokens.Enqueue(tok);
            return _pendingTokens.Dequeue();
        }

        return new Token(TType.STRING, tail, 0, 0, startLine);
    }

    // Pending tokens generated by interpolation expansion
    readonly Queue<Token> _pendingTokens = new();

    Token ReadNumber() {
        var sb   = new StringBuilder();
        bool isF = false;
        if (Cur == '-') { sb.Append(Cur); Adv(); }
        while (_pos < _src.Length && (char.IsDigit(Cur) || Cur == '.')) {
            if (Cur == '.') { if (isF) break; isF = true; }
            sb.Append(Cur); Adv();
        }
        string raw = sb.ToString();
        return isF
            ? new Token(TType.FLOAT, raw, 0,            double.Parse(raw), _line)
            : new Token(TType.INT,   raw, long.Parse(raw), 0,              _line);
    }

    Token ReadIdent() {
        var sb = new StringBuilder();
        while (_pos < _src.Length && (char.IsLetterOrDigit(Cur) || Cur == '_')) {
            sb.Append(Cur); Adv();
        }
        string word = sb.ToString();
        TType  type = KwMap.TryGetValue(word, out TType kt) ? kt : TType.IDENT;
        return new Token(type, word, 0, 0, _line);
    }

    Token? ReadSymbol() {
        char c = Cur; char n = Next;

        if (c == '=' && n == '=') { Adv(); Adv(); return new Token(TType.EQEQ,    "==", 0, 0, _line); }
        if (c == '!' && n == '=') { Adv(); Adv(); return new Token(TType.NEQ,     "!=", 0, 0, _line); }
        if (c == '<' && n == '=') { Adv(); Adv(); return new Token(TType.LTE,     "<=", 0, 0, _line); }
        if (c == '>' && n == '=') { Adv(); Adv(); return new Token(TType.GTE,     ">=", 0, 0, _line); }
        if (c == '+' && n == '=') { Adv(); Adv(); return new Token(TType.PLUSEQ,  "+=", 0, 0, _line); }
        if (c == '-' && n == '=') { Adv(); Adv(); return new Token(TType.MINUSEQ, "-=", 0, 0, _line); }
        if (c == '*' && n == '=') { Adv(); Adv(); return new Token(TType.STAREQ,  "*=", 0, 0, _line); }
        if (c == '/' && n == '=') { Adv(); Adv(); return new Token(TType.SLASHEQ, "/=", 0, 0, _line); }

        TType? t = c switch {
            '=' => TType.EQ,       '<' => TType.LT,        '>' => TType.GT,
            '+' => TType.PLUS,     '-' => TType.MINUS,     '*' => TType.STAR,
            '/' => TType.SLASH,    '%' => TType.PERCENT,
            '(' => TType.LPAREN,   ')' => TType.RPAREN,
            '{' => TType.LBRACE,   '}' => TType.RBRACE,
            '[' => TType.LBRACKET, ']' => TType.RBRACKET,
            ',' => TType.COMMA,    '.' => TType.DOT,       ':' => TType.COLON,
            _   => (TType?)null
        };

        if (t == null) return null;
        Adv();
        return new Token(t.Value, c.ToString(), 0, 0, _line);
    }

    bool IsExprStart(List<Token> toks) {
        if (toks.Count == 0) return true;
        return toks[^1].Type switch {
            TType.EQ      or TType.COMMA   or TType.LPAREN   or TType.LBRACKET or
            TType.PLUS    or TType.MINUS   or TType.STAR     or TType.SLASH    or
            TType.PERCENT or TType.EQEQ   or TType.NEQ      or TType.LT       or
            TType.GT      or TType.LTE    or TType.GTE      or TType.AND      or
            TType.OR      or TType.NOT    or TType.MAKE     or TType.SAY      or
            TType.CALC    or TType.GIVE   or TType.CYCLE    or TType.RAND     or
            TType.PLUSEQ  or TType.MINUSEQ or TType.STAREQ  or TType.SLASHEQ  => true,
            _ => false
        };
    }

    // Called by Tokenize loop — drain pending tokens first
    public List<Token> TokenizeAll() {
        var raw = Tokenize_Internal();
        return raw;
    }

    List<Token> Tokenize_Internal() {
        var toks = new List<Token>();

        while (_pos < _src.Length) {
            // drain any pending tokens from interpolation
            while (_pendingTokens.Count > 0) toks.Add(_pendingTokens.Dequeue());

            char c = Cur;

            if (c == '\n') { _line++; Adv(); continue; }
            if (c == ' ' || c == '\t' || c == '\r') { Adv(); continue; }
            if (c == '#') { while (_pos < _src.Length && Cur != '\n') Adv(); continue; }

            if (c == '"' || c == '\'') { toks.Add(ReadString(c)); continue; }

            if (char.IsDigit(c) || (c == '-' && char.IsDigit(Next) && IsExprStart(toks))) {
                toks.Add(ReadNumber()); continue;
            }

            if (char.IsLetter(c) || c == '_') { toks.Add(ReadIdent()); continue; }

            var sym = ReadSymbol();
            if (sym != null) { toks.Add(sym); continue; }

            Err($"Unknown character '{c}'");
        }

        // drain any remaining pending tokens
        while (_pendingTokens.Count > 0) toks.Add(_pendingTokens.Dequeue());

        toks.Add(new Token(TType.EOF, "<eof>", 0, 0, _line));
        return toks;
    }
}