namespace GSL;

using System;
using System.Text.RegularExpressions;

public static class ErrorHandler {
    public static void Report(Exception ex, string? source = null) {
        Console.ResetColor();

        // 1. Extract Line Number using Regex from your "[Line X]" format
        int lineNum = 1;
        var match = Regex.Match(ex.Message, @"\[Line (\d+)\]");
        if (match.Success) lineNum = int.Parse(match.Groups[1].Value);

        // 2. Determine Error Type & Theme
        string type = "RUNTIME ERROR";
        ConsoleColor theme = ConsoleColor.Red;

        if (ex.Message.Contains("Lex error")) {
            type = "LEXER ERROR";
            theme = ConsoleColor.Magenta;
        } else if (ex.Message.Contains("Parse error")) {
            type = "PARSER ERROR";
            theme = ConsoleColor.Cyan;
        }

        // 3. Print Header Badge
        Console.WriteLine();
        Console.BackgroundColor = theme;
        Console.ForegroundColor = ConsoleColor.Black;
        Console.Write($" {type} ");
        Console.ResetColor();
        Console.ForegroundColor = ConsoleColor.Gray;
        Console.WriteLine($" at line {lineNum}");

        // 4. Print Clean Message (strips internal [Line X] prefix)
        string cleanMsg = Regex.Replace(ex.Message, @"\[Line \d+\] (Lex error: |Parse error: )?", "");
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine($" > {cleanMsg}");
        Console.ResetColor();

        // 5. Code Snippet Visualization
        if (!string.IsNullOrEmpty(source)) {
            string[] lines = source.Split('\n');
            if (lineNum > 0 && lineNum <= lines.Length) {
                Console.WriteLine();
                string lineContent = lines[lineNum - 1].Replace("\r", "");
                
                // Gutter (Line Number)
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.Write($"{lineNum.ToString().PadLeft(4)} | ");
                
                // The actual code line
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(lineContent.TrimStart());
                
                // The Arrow Pointer
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.Write("     | ");
                Console.ForegroundColor = theme;
                Console.WriteLine("^--- here");
            }
        }
        Console.ResetColor();
        Console.WriteLine();
    }
}